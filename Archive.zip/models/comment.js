const { Sequelize, DataTypes } = require('sequelize');

const db = require('./database')
const Comment = db.define('Comment', {
    text:{
        type: Sequelize.DataTypes.STRING
    }
})
Comment.associte = module =>{
    Comment.belongsTo(module.User)
    Comment.belongsTo(module.Post)
}
module.exports = Comment