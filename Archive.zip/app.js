require ('dotenv').config();
const express = require('express')
const router = require('./routes')
const cors = require('cors')
const morgan = require('morgan')
const bodyParser = require('body-parser')
const port = process.env.PORT || 4000
const db = require ('./models/database')
const models =require('./models')

const app = express();



app.use(cors());

app.use(morgan('dev'));

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())
app.use('*/images', express.static(__dirname + '/public/images'))
app.use('/',router);



db.sync({ alter: true }).then(()=>{
    
    app.listen(port ,() =>{
        console.log('server app workong '+port)
    });

})
