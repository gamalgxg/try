const { body, validationResult } = require('express-validator');

const userValidationResult = () => {
    return[
        body('name').notEmpty().withMessage('اسم المستخدم مطلوب'),
        body('email').notEmpty().withMessage('البريد الالكتروني مطلوب'),
        body('password').notEmpty().withMessage(' كلمة السر طلوبة'),
        body('password').isLength({min:6}).withMessage(' كلمة السر يجب ان تكون ٦ احرف اقل شي')
    ]
}
const validationResulltUpdate  = () => {
    return [
        body('name').notEmpty().withMessage('اسم المستخدم مطلوب'),
        body('password').notEmpty().withMessage(' كلمة السر طلوبة'),
        body('password').isLength({min:6}).withMessage(' كلمة السر يجب ان تكون ٦ احرف اقل شي')
    ]
}
const validationResultPost = ()=> {
    return[
        body('title').notEmpty().withMessage('عنوان المنشور مطلوب'),
        body('contents').notEmpty().withMessage('محتوى المنشور مطلوب'),
        body('steps').notEmpty().withMessage('خطوات المنشور مطلوبة'),

    ]
}
const vaidate = (req,res,next) => {
    const x = validationResult(req);
if (x.isEmpty()) {
  return next()
}
return res.status(400).json({ errors: x.array()});
}
module.exports = {
    userValidationResult,
    vaidate,
    validationResulltUpdate,
    validationResultPost
}
