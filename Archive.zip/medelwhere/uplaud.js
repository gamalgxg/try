const multer  = require('multer')
const DIR = './public/images'
const storage = multer.diskStorage({
    destination:(req,file,cb) => {
        cb(null,DIR)
 
    },
    filename: (req, file,cb) => {
        let xtrArray = file.mimetype.split('/')
        let extantion = xtrArray[1]
        const uniqueSuffix = Date.now() + '_' + Math.random(Math.max() *1E9)
        cb(null,file.fieldname + '_' + uniqueSuffix +'.'+ extantion)
        console.log(extantion)
    }
})
const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype == 'image/png' || file.mimetype == 'image/jpg' || file.mimetype == 'image/jpeg') {
            cb(null,true)
        } else{
            cb (new multer.MulterError("هذا الملف ليس صورة"))
        }
    }
})

module.exports= upload