const model = require('../models')

exports.newPost = async (req,res) => {
    const {title,contents , steps, country, region} = req.body
    const url =req.protocol + '://'+ req.get('host')

    try {
        const post = await model.Post.create({
            title,
            contents,
            steps,
            country,
            region,
            UserId: req.currentUser.id
        })
        req.files.map( async (file)=>{
            const postImage = await model.Post_img.create({
                img_uri : url + '/public/images/' + file.fiename ,
                PostId : post.id
            })
        })
        res.status(200).json('تم اضافة منشور جديد')
    } catch (e) {
        res.status(500).json(e)

    }
}
exports.getAllPost = async (req,res) => {
    try {
        const getPosts = await model.Post.findAll({
            include: [
                {
                    model: model.User,
                    attributes: {exclude: ['password' , 'email']}
                },
                {
                    model: model.Post_img
                },
            ]
        })
        res.status(200).json(getPosts)

    } catch (e) {
        res.status(500).json(e)

    }
}


